﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson6._1
{
    public class TextContainer
    {
        // Строковое поле
        private string _content;

        // Свойство для доступа к полю
        public string Content
        {
            get { return _content; }
            set { _content = value; }
        }

        // Конструктор по умолчанию
        public TextContainer()
        {
            _content = string.Empty;
        }

        // Конструктор с параметром
        public TextContainer(string text)
        {
            _content = text;
        }

        // Конструктор копирования
        public TextContainer(TextContainer other)
        {
            _content = other._content;
        }

        // Метод, создающий строку из первого и последнего символов поля
        public string GetFirstAndLastChar()
        {
            if (string.IsNullOrEmpty(_content) || _content.Length < 2)
                return _content;

            return _content[0].ToString() + _content[_content.Length - 1].ToString();
        }

        // Перегрузка метода ToString()
        public override string ToString()
        {
            return $"Cодержимое: {_content}";
        }
    }

}
