﻿using Lesson6._1;

internal class Program
{
    private static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.InputEncoding = System.Text.Encoding.UTF8;

        // Тестирование базового класса
        Console.WriteLine("ТЕСТИРОВАНИЕ БАЗОВОГО КЛАССА\n");

        // Создание объекта базового класса с вводом данных
        string text = InputValidator.GetNonEmptyString("Введите текст: ");
        TextContainer textObj = new TextContainer(text);

        Console.WriteLine("Объект базового класса:");
        Console.WriteLine(textObj.ToString());

        // Тестирование метода GetFirstAndLastChar
        Console.WriteLine($"Первый и последний символы: {textObj.GetFirstAndLastChar()}");

        // Тестирование конструктора копирования
        TextContainer copiedText = new TextContainer(textObj);

        Console.WriteLine("Оригинальный объект:");
        Console.WriteLine(textObj.ToString());

        Console.WriteLine("Копия:");
        Console.WriteLine(copiedText.ToString());

        // Тестирование дочернего класса
        Console.WriteLine("\nТЕСТИРОВАНИЕ ДОЧЕРНЕГО КЛАССА\n");

        // Создание объекта дочернего класса с вводом данных
        string title = InputValidator.GetNonEmptyString("Введите название книги: ");
        string author = InputValidator.GetNonEmptyString("Введите автора: ");
        int year = InputValidator.GetInteger("Введите год публикации: ", 1, DateTime.Now.Year);

        Book book = new Book(title, author, year);

        Console.WriteLine("Информация о книге:");
        Console.WriteLine(book.ToString());

        // Тестирование методов дочернего класса
        Console.WriteLine($"Первый и последний символы названия: {book.GetFirstAndLastChar()}");
        Console.WriteLine($"Полная информация о книге:{book.GetFullInfo()}");
        Console.WriteLine($"Возраст книги: {book.GetAge()} лет");
        Console.WriteLine($"Является ли книга классической: {(book.IsClassic() ? "Да" : "Нет")}");

        // Тестирование конструктора копирования
        Book copiedBook = new Book(book);
        copiedBook.Content += " (копия)";

        Console.WriteLine("Информация об оригинальной книге:");
        Console.WriteLine(book.ToString());

        Console.WriteLine("Информация о скопированной книге:");
        Console.WriteLine(copiedBook.ToString());
    }
}