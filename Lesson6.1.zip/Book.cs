﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson6._1
{
    public class Book : TextContainer
    {

        private string _author;
        private int _publicationYear;

        public string Author
        {
            get { return _author; }
            set { _author = value; }
        }

        public int PublicationYear
        {
            get { return _publicationYear; }
            set { _publicationYear = value; }
        }

        public Book() : base()
        {
            _author = string.Empty;
            _publicationYear = 0;
        }

        public Book(string title, string author, int publicationYear) : base(title)
        {
            _author = author;
            _publicationYear = publicationYear;
        }

        public Book(Book other) : base(other)
        {
            _author = other._author;
            _publicationYear = other._publicationYear;
        }

        public bool IsClassic()
        {
            return DateTime.Now.Year - _publicationYear > 50;
        }

        public string GetFullInfo()
        {
            return $"Название: {Content}\nАвтор: {_author}\nГод публикации: {_publicationYear}";
        }


        public int GetAge()
        {
            return DateTime.Now.Year - _publicationYear;
        }


        public override string ToString()
        {
            return $"Книга: {Content}, автор: {_author}, год публикации: {_publicationYear}";
        }
    }

}
