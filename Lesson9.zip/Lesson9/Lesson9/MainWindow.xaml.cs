﻿using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lesson9
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {



        public MainWindow()
        {
            InitializeComponent();
            AllTimers = new ObservableCollection<Time>();
        }
        public ObservableCollection<Time> AllTimers { get; set; }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }


        private void CreateTime(object sender, RoutedEventArgs e)
        {
            string hours = HoursBox.Text;
            string minutes = MinutesBox.Text;
            byte b;
            if (byte.TryParse(hours, out b) && byte.TryParse(minutes, out b))
            {
                AllTimers.Add(new Time(Convert.ToByte(hours), Convert.ToByte(minutes)));

                TimeGrid.ItemsSource = AllTimers;
            }
            else
            {
                MessageBox.Show("Значение не соответствует типу byte", "Ошибка создания",
    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void TimeTable_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Inc_Click(object sender, RoutedEventArgs e)
        {
            if (TimeGrid.SelectedItems.Count == 1)
            {
                AllTimers[TimeGrid.SelectedIndex]++;
            }
            else
            {
                MessageBox.Show("Выберете один элемент в списке", "Ошибка выбора",
    MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        private void Dec_Click(object sender, RoutedEventArgs e)
        {
            if (TimeGrid.SelectedItems.Count == 1)
            {
                AllTimers[TimeGrid.SelectedIndex]--;
            }
            else 
            {
                MessageBox.Show("Выберете один элемент в списке", "Ошибка выбора",
    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (TimeGrid.SelectedItems.Count == 1)
            {
                string s = MinutesToAddingBox.Text;
                uint u;
                if (uint.TryParse(s, out u))
                {
                    AllTimers[TimeGrid.SelectedIndex].addminutes(AllTimers[TimeGrid.SelectedIndex], Convert.ToUInt32(s));
                }
                else
                {
                    MessageBox.Show("Значение не соответствует типу Uint", "Ошибка добавления",
    MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Выберете один элемент в списке", "Ошибка выбора",
    MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (TimeGrid.SelectedItems.Count == 1)
            {
                Output.Text = AllTimers[TimeGrid.SelectedIndex].ToString();
            }   
            else 
            {
                MessageBox.Show("Выберете один элемент в списке", "Ошибка выбора",
    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (TimeGrid.SelectedItems.Count == 1)
            {
                bool b = AllTimers[TimeGrid.SelectedIndex];
                    Output.Text = b.ToString();
            }
            else
            {
            MessageBox.Show("Выберете один элемент в списке", "Ошибка выбора",
        MessageBoxButton.OK, MessageBoxImage.Error);
             }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            if (TimeGrid.SelectedItems.Count == 1)
            {
                byte b = (byte)AllTimers[TimeGrid.SelectedIndex];
                Output.Text = b.ToString();
            }
            else
            {
                MessageBox.Show("Выберете один элемент в списке", "Ошибка выбора",
            MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}