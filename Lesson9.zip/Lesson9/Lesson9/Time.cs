﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson9
{
    public class Time
    {
        public byte hours { get; set; }
        public byte minutes { get; set; }

        public Time(byte hours, byte minutes)
        {
            if (minutes > 59)
            {
                this.hours = (byte)((hours + minutes / 60)%24);
                this.minutes = (byte)(minutes % 60);
            }
            else
            {
                this.hours = (byte)(hours % 24);
                this.minutes = minutes;
            }

        }
        public Time addminutes(Time time, uint additionalMinutes)
        {
            time.hours = (byte)((time.hours + (time.minutes + additionalMinutes) / 60)%24);
            time.minutes = (byte)((time.minutes + additionalMinutes) % 60);
            return time;
        }
        public override string ToString()
        {
            return (hours.ToString() + " часов " + minutes.ToString() + " минут");
        }

        public static Time operator ++(Time time)
        {
            return time.addminutes(time, 1);
        }
        public static Time operator --(Time time)
        {
            if (time.minutes == 0)
            {
                if (time.hours == 0)
                {
                    Console.WriteLine("Время не может быть отрицательным");
                    return time;
                }
                time.hours -= 1;
                time.minutes = 59;

            }
            else
            {
                time.minutes -= 1;
            }
            return time;
        }


        public static explicit operator byte(Time time)
        {
            return time.hours;
        }
        public static implicit operator bool(Time time)
        {
            return (time.hours != 0 && time.minutes != 0);
        }


    }

    
}
