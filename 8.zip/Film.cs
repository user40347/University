﻿using System;

public class Film
{
    // Уникальный идентификатор — ключ удаления/поиска
    public int Id { get; set; }

    // Название фильма
    public string Title { get; set; }

    // Режиссёр
    public string Director { get; set; }

    // Год выпуска
    public int Year { get; set; }

    // Жанр
    public string Genre { get; set; }

    // Рейтинг IMDb (число с плавающей точкой)
    public double Rating { get; set; }

    // Длительность в минутах
    public double DurationMinutes { get; set; }

    public Film(int id, string title, string director, int year, string genre, double rating, double durationMinutes)
    {
        Id = id;
        Title = title;
        Director = director;
        Year = year;
        Genre = genre;
        Rating = rating;
        DurationMinutes = durationMinutes;
    }

    public override string ToString()
    {
        return $"{Id}: \"{Title}\" ({Year}), реж. {Director}, жанр {Genre}, рейтинг {Rating:F1}, длительность {DurationMinutes:F0} мин.";
    }
}
