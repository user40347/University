﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        var films = FilmRepository.Load();

        while (true)
        {
            Console.WriteLine("\n--- Каталог фильмов ---");
            Console.WriteLine("1. Просмотр всех фильмов");
            Console.WriteLine("2. Добавить фильм");
            Console.WriteLine("3. Удалить фильм");
            Console.WriteLine("4. Запросы по каталогу");
            Console.WriteLine("0. Выход");
            Console.Write("Выберите действие: ");

            if (!int.TryParse(Console.ReadLine(), out int choice))
            {
                Console.WriteLine("Неверный ввод. Введите число.");
                continue;
            }

            switch (choice)
            {
                case 1:
                    FilmRepository.ViewAll(films);
                    break;

                case 2:
                    try
                    {
                        Console.Write("ID: ");
                        int id = int.Parse(Console.ReadLine());
                        Console.Write("Название: ");
                        string title = Console.ReadLine();
                        Console.Write("Режиссёр: ");
                        string director = Console.ReadLine();
                        Console.Write("Год: ");
                        int year = int.Parse(Console.ReadLine());
                        Console.Write("Жанр: ");
                        string genre = Console.ReadLine();
                        Console.Write("Рейтинг: ");
                        double rating = double.Parse(Console.ReadLine());
                        Console.Write("Длительность (мин): ");
                        double duration = double.Parse(Console.ReadLine());

                        var newFilm = new Film(id, title, director, year, genre, rating, duration);
                        FilmRepository.Add(films, newFilm);
                    }
                    catch
                    {
                        Console.WriteLine("Ошибка при вводе данных.");
                    }
                    break;

                case 3:
                    Console.Write("Введите ID для удаления: ");
                    if (int.TryParse(Console.ReadLine(), out int delId))
                        FilmRepository.Delete(films, delId);
                    else
                        Console.WriteLine("Неверный ID.");
                    break;

                case 4:
                    ShowQueries(films);
                    break;

                case 0:
                    return;

                default:
                    Console.WriteLine("Недопустимый пункт меню.");
                    break;
            }
        }
    }

    static void ShowQueries(List<Film> films)
    {
        Console.WriteLine("\n--- Запросы ---");
        Console.WriteLine("1. Фильмы жанра");
        Console.WriteLine("2. Фильмы режиссёра после года");
        Console.WriteLine("3. Максимальный рейтинг");
        Console.WriteLine("4. Средняя длительность");
        Console.Write("Выберите запрос: ");

        if (!int.TryParse(Console.ReadLine(), out int q))
        {
            Console.WriteLine("Неверный ввод.");
            return;
        }

        switch (q)
        {
            case 1:
                Console.Write("Жанр: ");
                foreach (var f in FilmRepository.GetByGenre(films, Console.ReadLine()))
                    Console.WriteLine(f);
                break;
            case 2:
                Console.Write("Режиссёр: ");
                string dir = Console.ReadLine();
                Console.Write("Год: ");
                if (int.TryParse(Console.ReadLine(), out int yr))
                    foreach (var f in FilmRepository.GetByDirectorAfterYear(films, dir, yr))
                        Console.WriteLine(f);
                break;
            case 3:
                var maxR = FilmRepository.GetMaxRating(films);
                Console.WriteLine(maxR.HasValue ? $"Максимальный рейтинг: {maxR:F1}" : "Нет данных.");
                break;
            case 4:
                var avg = FilmRepository.GetAverageDuration(films);
                Console.WriteLine(avg.HasValue ? $"Средняя длительность: {avg:F1} мин." : "Нет данных.");
                break;
            default:
                Console.WriteLine("Неверный запрос.");
                break;
        }
    }
}
