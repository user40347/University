﻿using Lesson_6._2;



    byte hours = Validator.ReadByte("Часы (0-23): ", 0, 23);
    byte minutes = Validator.ReadByte("Минуты: ", 0, 255);

    Time time = new Time(hours, minutes);




    Console.WriteLine($"Исходное время: {time}");
    bool isValid = time;
    Console.WriteLine($"Время не нулевое: {isValid}");
    byte toByte = (byte)time;
    Console.WriteLine($"Время в байты: {toByte}");
    Console.WriteLine();
    Time t2 = --time;
    Console.WriteLine($"После --: {t2}");
    Time t1 = time++;
    Console.WriteLine($"После ++(Значение изменяется только после действия присвоения): {t1}");
    Time t3 = time + Validator.ReadUInt("Введите количество минут для добавления\n");
    Console.WriteLine($"После добавления минут: {t3}");
    Time t4 = time - Validator.ReadUInt("Введите количество минут для вычитания\n");
    Console.WriteLine($"После вычитания минут: {t4}");





