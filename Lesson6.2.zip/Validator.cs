﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_6._2
{
    public static class Validator
    {
        public static byte ReadByte(string prompt, byte min, byte max)
        {
            byte result;
            do
            {
                Console.Write(prompt);
            } while (!byte.TryParse(Console.ReadLine(), out result) || result < min || result > max);

            return result;
        }

        public static uint ReadUInt(string prompt)
        {
            uint result;
            do
            {
                Console.Write(prompt);
            } while (!uint.TryParse(Console.ReadLine(), out result));

            return result;
        }
    }


}
