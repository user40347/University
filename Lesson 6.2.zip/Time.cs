﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson_6._2
{
    public class Time
    {
        private byte _hours;
        private byte _minutes;

        // Конструкторы остаются без изменений
        public Time() : this(0, 0) { }

        public Time(byte hours, byte minutes)
        {
            if (hours > 23)
                throw new ArgumentException("Некорректное время");

            _hours = (byte)(hours + (byte)(minutes/60));
            _minutes = (byte)(minutes % 60);
        }

        // Основной метод добавления минут
        public Time AddMinutes(uint minutesToAdd)
        {
            int totalMinutes = _hours * 60 + _minutes;
            totalMinutes += (int)minutesToAdd;
            return ConvertMinutes(totalMinutes);
        }

        // Новый метод вычитания минут
        public Time SubtractMinutes(uint minutesToSubtract)
        {
            int totalMinutes = _hours * 60 + _minutes - ((int)minutesToSubtract);
            return ConvertMinutes(totalMinutes);
        }

        private Time ConvertMinutes(int totalMinutes)
        {
            totalMinutes %= 1440;
            if (totalMinutes < 0) totalMinutes += 1440;

            return new Time(
                (byte)(totalMinutes / 60),
                (byte)(totalMinutes % 60)
            );
        }




        public static Time operator ++(Time t) => t.AddMinutes(1);
        public static Time operator --(Time t) => t.SubtractMinutes(1);

        public static Time operator +(Time t, uint minutes) => t.AddMinutes(minutes);
        public static Time operator +(uint minutes, Time t) => t.AddMinutes(minutes);

        public static Time operator -(Time t, uint minutes) => t.SubtractMinutes(minutes);
        public static Time operator -(uint minutes, Time t) => t.SubtractMinutes(minutes);

        public override string ToString() => $"{_hours:D2}:{_minutes:D2}";
        public static explicit operator byte(Time t) => t._hours;
        public static implicit operator bool(Time t) => t._hours != 0 || t._minutes != 0;
    }






}
