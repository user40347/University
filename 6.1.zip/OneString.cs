﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson1N
{
    public class OneString
    {
        public OneString(OneString previousString)
        {

            this.FString = previousString.FString;


        }


        public OneString(string firstString)
        {
            this.FString = firstString;

        }

        protected string FString { get; set; }

        public string FLSymbols()
        {
            if (FString != "")
            {
                return FString[0].ToString() + FString[FString.Length - 1].ToString();
            }
            return FString;

        }

        public override string ToString()
        {
            return FString;
        }
    }
}
