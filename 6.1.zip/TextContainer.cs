﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson6._1
{
    public class TextContainer
    {

        private string _content;

        public string Content
        {
            get { return _content; }
            set { _content = value; }
        }

        public TextContainer()
        {
            _content = string.Empty;
        }

        public TextContainer(string text)
        {
            _content = text;
        }


        public TextContainer(TextContainer other)
        {
            _content = other._content;
        }


        public string GetFirstAndLastChar()
        {
            if (string.IsNullOrEmpty(_content) || _content.Length < 2)
                return _content;

            return _content[0].ToString() + _content[_content.Length - 1].ToString();
        }


        public override string ToString()
        {
            return $"Cодержимое: {_content}";
        }
    }

}
