﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson6._1
{
    public class InputValidator
    {

        public static string GetNonEmptyString(string prompt)
        {
            string input;
            do
            {
                Console.Write(prompt);
                input = Console.ReadLine()?.Trim();
                if (string.IsNullOrEmpty(input))
                {
                    Console.WriteLine("Ошибка: Введите непустую строку.");
                }
            } while (string.IsNullOrEmpty(input));

            return input;
        }


        public static int GetInteger(string prompt, int minValue = int.MinValue, int maxValue = int.MaxValue)
        {
            int result;
            bool isValid;

            do
            {
                Console.Write(prompt);
                string input = Console.ReadLine();
                isValid = int.TryParse(input, out result);

                if (!isValid)
                {
                    Console.WriteLine("Ошибка: Введите корректное целое число.");
                }
                else if (result < minValue || result > maxValue)
                {
                    Console.WriteLine($"Ошибка: Введите число в диапазоне от {minValue} до {maxValue}.");
                    isValid = false;
                }
            } while (!isValid);

            return result;
        }
    }

}
