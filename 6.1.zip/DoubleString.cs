﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson1N
{
    public class DoubleString : OneString
    {
        public string SecondString { get; set; }

        public DoubleString(string firstString, string secondString)
            : base(firstString)
        {

            SecondString = secondString;

        }

        public string SumStrings()
        {
            return FString + SecondString;
        }

        public string CBCComparsionStrings() //Получение строки, путем отбора совпадающих на позициях символов
        {
            string res = "";

            for (int i = 0; i < FString.Length; i++)
            {

                if (SecondString.Length > i & FString[i] == SecondString[i])
                {
                    res += FString[i];
                }



            }
            return res;

        }


    }
}
