﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LB9
{
    public static class Validator
    {
        public static byte ReadByte(string text, byte min, byte max)
        {
            if (!byte.TryParse(text, out byte value) || value < min || value > max)
                throw new ArgumentException($"Значение должно быть от {min} до {max}");
            return value;
        }

        public static uint ReadUInt(string text)
        {
            if (!uint.TryParse(text, out uint value))
                throw new ArgumentException("Ожидалось неотрицательное целое число");
            return value;
        }
    }

}
