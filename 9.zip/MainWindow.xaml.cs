﻿using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LB9
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Time _currentTime;

        public MainWindow()
        {
            InitializeComponent();
            ResultTextBlock.Text = "Введите время и нажмите кнопку.";
        }

        // Ограничить ввод только цифрами
        private void NumberOnly_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !Regex.IsMatch(e.Text, "^[0-9]+$");
        }

        // Чтение и установка начального времени
        private bool TryReadTime(out Time time)
        {
            time = null;
            try
            {
                byte hours = Validator.ReadByte(HoursTextBox.Text, 0, 23);
                byte minutes = Validator.ReadByte(MinutesTextBox.Text, 0, 255);
                time = new Time(hours, minutes);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        private void Increment_Click(object sender, RoutedEventArgs e)
        {
            if (_currentTime == null && !TryReadTime(out _currentTime)) return;
            _currentTime++;
            ShowResult("После увеличения на 1 минуту");
        }

        private void Decrement_Click(object sender, RoutedEventArgs e)
        {
            if (_currentTime == null && !TryReadTime(out _currentTime)) return;
            _currentTime--;
            ShowResult("После уменьшения на 1 минуту");
        }

        private void AddMinutes_Click(object sender, RoutedEventArgs e)
        {
            if (_currentTime == null && !TryReadTime(out _currentTime)) return;
            if (!uint.TryParse(AddTextBox.Text, out uint m))
            {
                MessageBox.Show("Неверное число минут", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            _currentTime = _currentTime + m;
            ShowResult($"После добавления {m} минут");
        }

        private void SubtractMinutes_Click(object sender, RoutedEventArgs e)
        {
            if (_currentTime == null && !TryReadTime(out _currentTime)) return;
            if (!uint.TryParse(AddTextBox.Text, out uint m))
            {
                MessageBox.Show("Неверное количество минут", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            _currentTime = _currentTime - m;
            ShowResult($"После вычитания {m} минут");
        }

        private void ShowResult(string action)
        {
            ResultTextBlock.Text = $"{action}: {_currentTime}\n" +
                                   $"В булевом контексте: {(_currentTime ? "не нулевое" : "нулевое")}\n" +
                                   $"Явное приведение к byte (часы): {(byte)_currentTime}";
        }
    }

}